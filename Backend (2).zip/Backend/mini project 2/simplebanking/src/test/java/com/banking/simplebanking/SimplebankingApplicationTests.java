package com.banking.simplebanking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimplebankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
