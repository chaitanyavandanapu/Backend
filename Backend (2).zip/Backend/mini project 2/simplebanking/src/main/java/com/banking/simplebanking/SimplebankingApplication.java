package com.banking.simplebanking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplebankingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimplebankingApplication.class, args);
	}

}
