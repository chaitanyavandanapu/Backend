public class Replace {
    public static void main (String[] args){
        String value="1.1";
        double num=Double.parseDouble(value);
        double sum=10;
        sum+=num;
        System.out.println(sum);
    }
}
