package Day4;

class Day4 {
    public static void main(String[] args) {
        System.out.println("Day4");
    }
}
