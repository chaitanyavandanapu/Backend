import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import java.util.*;
public class Conversions {
    public static void main(String[] args) {
        //explicit conversion
//        int x = (int) (Math.random() * 10);
//        System.out.println(x);
//        //implicit conversion
//        int a = 10;
//        double b = a;
//        System.out.println(b);
//
//        //printing multdimensional array
//        int[][] arr = {{1, 2, 3}, {4, 5, 6}};
//        System.out.println(Arrays.deepToString(arr));
//
//        NumberFormat num=NumberFormat.getCurrencyInstance();
//        System.out.println(num.format(12_344_567F));
//
//        NumberFormat percentage=NumberFormat.getPercentInstance();
//        System.out.println(percentage.format(0.1));

        Date d = new Date();
        String date = d.toString();
        String day = date.substring(0, 3);
        switch (day) {
            case "Mon":
                System.out.println("hi");
                break;
            case "Fri":
                System.out.println("happy weekend");
                //default:
                //System.out.println("Have a good day");
        }

        int[][] arr = {{1, 2, 3, 4}, {5, 6, 7, 8, 9}};
        for (int[] num : arr) {
            for (int n : num) {
                System.out.println(n);
            }


        }
    }
}