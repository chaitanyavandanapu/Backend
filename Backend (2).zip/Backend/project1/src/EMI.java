import java.text.NumberFormat;
import java.util.Scanner;
public class EMI {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NumberFormat percentage=NumberFormat.getPercentInstance();
        NumberFormat currency=NumberFormat.getCurrencyInstance();
        System.out.print("Enter annual interest rate in %: ");
        double annualrate=sc.nextDouble();
        double r=(annualrate/100)/12;
        System.out.print("Enter principal amount: ");
        double p = sc.nextDouble();
        System.out.print("Enter number of years: ");
        int years=sc.nextInt();
        double n=years*12;
        double a= r*Math.pow((1+r),n);
        double b=Math.pow((1+r),n)-1;
        double c=a/b;
        double d=p*c;
        System.out.println("EMI amount is "+currency.format(d));
    }
}
