
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator; // For iterating

//class ArrList{
//
//    public static void main(String[] args) {
//        // 1. Declaration and Initialization
//        // Creating an ArrayList to store String objects (student names)
//        ArrayList<String> studentNames = new ArrayList<>();
//        System.out.println("Initial studentNames: " + studentNames); // Output: []
//
//        // 2. Adding Elements
//        studentNames.add("Alice"); // Adds to the end
//        studentNames.add("Bob");
//        studentNames.add("Charlie");
//        System.out.println("After adding 3 names: " + studentNames); // Output: [Alice, Bob, Charlie]
//
//        studentNames.add(1, "David"); // Adds "David" at index 1, shifting Bob and Charlie
//        System.out.println("After adding David at index 1: " + studentNames); // Output: [Alice, David, Bob, Charlie]
//
//        // 3. Accessing Elements
//        String firstStudent = studentNames.get(0);
//        System.out.println("First student: " + firstStudent); // Output: Alice
//
//        String thirdStudent = studentNames.get(2);
//        System.out.println("Third student: " + thirdStudent); // Output: Bob
//
//        // 4. Updating Elements
//        studentNames.set(3, "Eve"); // Replaces the element at index 3 (Charlie) with Eve
//        System.out.println("After updating index 3 to Eve: " + studentNames); // Output: [Alice, David, Bob,
//        // Eve]
//
//        // 5. Removing Elements
//        studentNames.remove(1); // Removes element at index 1 (David)
//        System.out.println("After removing student at index 1: " + studentNames); // Output: [Alice, Bob, Eve]
//
//        studentNames.remove("Bob"); // Removes the first occurrence of "Bob"
//        System.out.println("After removing Bob: " + studentNames); // Output: [Alice, Eve]
//
//        // 6. Checking Size
//        System.out.println("Current number of students: " + studentNames.size()); // Output: 2
//
//        // 7. Iterating (Looping through elements)
//        System.out.println("\n--- Iterating through student names ---");
//        // Using enhanced for loop (most common and readable)
//        for (String name : studentNames) {
//            System.out.println("Student: " + name);
//        }
//
//        // Using traditional for loop (useful if you need the index)
//        System.out.println("\n--- Iterating with index ---");
//        for (int i = 0; i < studentNames.size(); i++) {
//            System.out.println("Student at index " + i + ": " + studentNames.get(i));
//        }
//
//        // Using Iterator (more flexible for some scenarios, e.g., removing elements while iterating)
//        System.out.println("\n--- Iterating with Iterator ---");
//        studentNames.add("Frank"); // Add one more for iterator example
//        Iterator<String> iterator = studentNames.iterator();
//        while (iterator.hasNext()) {
//            String name = iterator.next();
//            System.out.println("Iterator Student: " + name);
//            if (name.equals("Eve")) {
//                iterator.remove(); // Removes Eve safely during iteration
//            }
//        }
//        System.out.println("After iterator removal of Eve: " + studentNames); // Output: [Alice, Frank]
//
//
//        // 8. Checking if an element exists
//        System.out.println("Contains 'Alice'? " + studentNames.contains("Alice")); // true
//        System.out.println("Contains 'Charlie'? " + studentNames.contains("Charlie")); // false
//
//        // 9. Clearing the ArrayList
//        studentNames.clear();
//        System.out.println("After clearing: " + studentNames); // Output: []
//        System.out.println("Is studentNames empty? " + studentNames.isEmpty()); // true
//    }
//
//}

//class Hmap{
//    public static void main(String[] args){
//        HashMap<String,Integer> hm=new HashMap<>();
//        hm.put("a",10);
//        hm.put("b",10);
//        hm.put("c",30);
//        hm.put("d",40);
//
//        for(Integer x:hm.values()){
//            System.out.println(x);
//        }
//
//    }
//}


import java.util.HashMap;
import java.util.Map; // For Map.Entry

class Hmap{

    public static void main(String[] args) {
        // 1. Declaration and Initialization
        // Creating a HashMap to store String keys (student IDs) and String values (student names)
        HashMap<String, String> studentRecords = new HashMap<>();
        System.out.println("Initial studentRecords: " + studentRecords); // Output: {}

        // 2. Adding Key-Value Pairs (Putting elements)
        studentRecords.put("S001", "Alice Smith");
        studentRecords.put("S002", "Bob Johnson");
        studentRecords.put("S003", "Charlie Brown");
        System.out.println("After adding 3 records: " + studentRecords);
        // Output might vary in order: {S003=Charlie Brown, S002=Bob Johnson, S001=Alice Smith}

        // Overwriting a value for an existing key
        studentRecords.put("S001", "Alicia Smith"); // Alice Smith is replaced by Alicia Smith
        System.out.println("After updating S001: " + studentRecords);
        // Output: {S003=Charlie Brown, S002=Bob Johnson, S001=Alicia Smith}

        // 3. Accessing Values
        String studentS002 = studentRecords.get("S002");
        System.out.println("Student with ID S002: " + studentS002); // Output: Bob Johnson

        String studentS004 = studentRecords.get("S004"); // Key not found
        System.out.println("Student with ID S004: " + studentS004); // Output: null

        // 4. Removing Key-Value Pairs
        studentRecords.remove("S003"); // Removes the entry for S003
        System.out.println("After removing S003: " + studentRecords);
        // Output: {S002=Bob Johnson, S001=Alicia Smith}

        // 5. Checking Size
        System.out.println("Current number of student records: " + studentRecords.size()); // Output: 2

        // 6. Checking for Keys and Values
        System.out.println("Contains key S001? " + studentRecords.containsKey("S001")); // true
        System.out.println("Contains key S003? " + studentRecords.containsKey("S003")); // false
        System.out.println("Contains value \"Bob Johnson\"? " + studentRecords.containsValue("Bob Johnson")); // true

        // 7. Iterating (Looping through HashMap)
        System.out.println("\n--- Iterating through keys ---");
        for (String studentId : studentRecords.keySet()) {
            System.out.println("ID: " + studentId);
        }

        System.out.println("\n--- Iterating through values ---");
        for (String studentName : studentRecords.values()) {
            System.out.println("Name: " + studentName);
        }

        System.out.println("\n--- Iterating through key-value pairs (Entry Set) ---");
        for (Map.Entry<String, String> entry : studentRecords.entrySet()) {
            System.out.println("ID: " + entry.getKey() + ", Name: " + entry.getValue());
        }

        // 8. Clearing the HashMap
        studentRecords.clear();
        System.out.println("After clearing: " + studentRecords); // Output: {}
        System.out.println("Is studentRecords empty? " + studentRecords.isEmpty()); // true
    }
}