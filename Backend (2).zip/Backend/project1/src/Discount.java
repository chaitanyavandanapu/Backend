import java.text.NumberFormat;
import java.util.Scanner;

public class Discount {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.print("Enter amount: ");
        double amount=sc.nextInt();
        double discount=0;
        if(amount>=500){
            discount=amount*0.20;
        }
        else if(amount>=100){
            discount=amount*0.10;
        }
        double finalamount=amount-discount;
        NumberFormat currency=NumberFormat.getCurrencyInstance();
        System.out.println("the amount to be paid after applying discount:"+currency.format(finalamount));
    }
}
