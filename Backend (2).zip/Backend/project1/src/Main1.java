import java.awt.*;

public class Main1 {
    public static void main(String args[]){
        int x=1,y=x;
        x=2;
        System.out.println(x);
        System.out.println(y);
        Point pointOne=new Point(x=3,y=4);
        Point pointTwo=pointOne;
        pointOne.x=5;
        System.out.println(pointOne);
        System.out.println(pointTwo);
    }
}
