import java.util.Arrays;

public class StringMethods {
    public  static void main(String[] args){
        String word1="hello";
        char[] charArray=word1.toCharArray();
        System.out.println(charArray[0]);
        String emptyString=" ";
        char[] emptyArray=emptyString.toCharArray();
        System.out.println(emptyArray);

        String s1="hello world";
        String s2="hello World";
        String s3="hii";
        String s4="hey";

        int len=s1.length();
        System.out.println(len);

        String[] split=s1.split(",");
        System.out.println(Arrays.toString(split));

        boolean b=s1.equals(s2);
        boolean b1=s1.equalsIgnoreCase(s2);
        boolean b2=s1.contains("h");
        System.out.println(b);
        System.out.println(b1);
        System.out.println(b2);
    }
}
