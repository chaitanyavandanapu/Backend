package com.example.demo.service;

import org.springframework.stereotype.Service;

@Service
public class HeloService {
    public String getMessage() {
        return "Hello from service";
    }
}
