package com.example.demo.controller;

import com.example.demo.service.HeloService;
import org.springframework.web.bind.annotation.*;

@RestController
public class HeloController {

    private final HeloService heloservice;

    public HeloController(HeloService heloservice) {
        this.heloservice = heloservice;
    }

    @GetMapping("/hello")
    public String sayhello() {
        return heloservice.getMessage();
    }
}

